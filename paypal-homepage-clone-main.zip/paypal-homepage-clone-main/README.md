# Paypal Homepage Clone by [TsbSankara](https://youtube.com/@tsbsankara)

## Assets

### Fonts

1. Oswald (Main Heading) - [Oswald](https://fonts.google.com/specimen/Oswald). Font weight - 500
2. Mukta - (Text) [Mukta](https://fonts.google.com/specimen/Mukta)
   Font weights - 200, 400

### Images

1. Logo - https://www.paypalobjects.com/webstatic/i/logo/rebrand/ppcom-white.svg

Find the remaining images in the `images` folder.

## Video

Link to video will be posted [here](https://youtube.com/@tsbsankara) when the project is completed.
