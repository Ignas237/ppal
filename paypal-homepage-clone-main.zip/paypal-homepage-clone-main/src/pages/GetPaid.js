import React from "react";

export default function GetPaid() {
  return <div>GetPaid</div>;
}
